<?php
// 声明文件解析的编码格式
header('content-type:text/html;charset=utf-8');
// 引入功能函数文件
require './public_function.php';

//声明一个变量用来存放sql语句
$department = array();
//通过函数获取得到所有的部门名称
$department = getName();

// 获取要编辑的员工的id
$emp_id = isset($_GET['emp_id']) ? intval($_GET['emp_id']) : 0;

//取得员工的部门名称
$deptName = getdept($emp_id);

// 判断是否有POST数据提交
if (!empty($_POST)) {
    
     // 定义变量$update，用来保存处理后的员工数据
    $update = array();
    
    // 定义合法字段数组
    $fields = array('emp_name', 'dept_name' , 'emp_birth', 'emp_entry');

    // 遍历$_POST，获取更新员工数据的键和值
    foreach ($fields as $v) {
        $data = isset($_POST[$v]) ? $_POST[$v] : '';
        //判断输入信息是否为空
        if ($data == '' || $data == '未选择') {
            exit($v.'请选择部门');
        }

        // 判断更改的是否为dept_name
        if($v == 'dept_name'){
            //将dept_name更改为`emp_dept_id`
            $v = 'emp_dept_id';
            $word = "'$data'";
            //得到特定部门的id
            $emp_dept_id = getdept_id($word);
            //将得到的id赋值给$values数组中的第二项
            $data = $emp_dept_id;
        }
        // 值也就是该字段保存的数据，对其进行安全处理
        $data = safeHandle($data);

        // 把键和值按照sql更新语句中的语法要求连接，并存入到$update数组中
        if($v == 'emp_dept_id')
            $update[] = "`$v`=$data";
        else
            $update[] = "`$v`='$data'";
    }

    // 把$update数组元素使用逗号连接，赋值给$update_str
    $update_str = implode(',', $update);

    // 组合sql语句
    $sql = "update `pre_emp` set $update_str where `emp_id`= $emp_id ";

    if ($res = query($sql)) {
        header('Location: ./show_emplist.php');
        exit;
    } else {
        exit('员工信息修改失败');
    }
} else {
    // 当没有表单提交时，查询当前要编辑的员工信息，展示到页面中

    // 编写SQL语句，查询相应ID的员工数据
    $sql = "select * from `pre_emp` where `emp_id`= '$emp_id' ";

    // 获取一行数据
    $pre_emp = fetchRow($sql);

    // 显示员工修改页面
    define('APP', 'itcast');
}
?>

<?php if(!defined('APP')) die('error!');?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>员工信息编辑</title>
<link rel="stylesheet" href="./jquery.datetimepicker.css"/>
<script src="./jquery.js"></script>
<script src="./jquery.datetimepicker.js"></script>
<script>
	$(function(){
		$('#date_of_birth').datetimepicker({lang:'ch'});
		$('#date_of_entry').datetimepicker({lang:'ch'});
	});
</script>
<style>
body{background-color:#eee;margin:0;padding:0;}
.box{width:400px;margin:15px auto;padding:20px;border:1px solid #ccc;background-color:#fff;}
.box h1{font-size:20px;text-align:center;}
.profile-table{margin:0 auto;}
.profile-table th{font-weight:normal;text-align:right;}
.profile-table input[type="text"]{width:180px;border:1px solid #ccc;height:22px;padding-left:4px;}
.profile-table .button{background-color:#0099ff;border:1px solid #0099ff;color:#fff;width:80px;height:25px;margin:0 5px;cursor:pointer;}
.profile-table .td-btn{text-align:center;padding-top:10px;}
.profile-table th,.profile-table td{padding-bottom:10px;}
.profile-table td{font-size:14px;}
.profile-table .txttop{vertical-align:top;}
.profile-table select{border:1px solid #ccc;min-width:80px;height:25px;}
.profile-table .description{font-size:13px;width:250px;height:60px;border:1px solid #ccc;}
</style>
</head>
<body>
<div class="box">
	<h1>编辑员工</h1>
	<form method="post">
	<table class="profile-table">
		<tr><th>姓名：</th><td><input type="text" name="emp_name" value="<?php echo $pre_emp['emp_name']; ?>"/></td></tr>
		<tr><th>所属部门：</th><td>
            <select style="width: 185px;" name="dept_name">
				<option value="未选择">未选择</option>
				<?php foreach($department as $v): ?>
					<option <?php if($deptName == $v) echo 'selected'; ?>> <?php echo $v ?> </option>
				<?php endForeach; ?>
		    </select>
        </td></tr>
		<tr><th>出生年月：</th><td><input id="emp_birth" name="emp_birth" type="text" value="<?php echo $pre_emp['emp_birth']; ?>"></td></tr>
		<tr><th>入职日期：</th><td><input id="emp_entry" name="emp_entry" type="text" value="<?php echo $pre_emp['emp_entry']; ?>"></td></tr>
		<tr><td colspan="2" class="td-btn">
		<input type="submit" value="保存资料" class="button" />
		<input type="button" value="返回列表" class="button" onclick="window.open('show_emplist.php')" />
		</td></tr>
	</table>
	</form>
</div>
</body>
</html>