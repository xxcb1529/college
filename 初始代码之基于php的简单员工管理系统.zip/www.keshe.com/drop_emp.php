<?php
// 声明文件解析的编码格式
header('content-type:text/html;charset=utf-8');

//接入封装的各个函数
require './public_function.php';

// 接入连接封装的函数，连接数据库
$link = dbInit();

// 获取要编辑的员工的id
$emp_id = isset($_GET['emp_id']) ? intval($_GET['emp_id']) : 0;

//定义一个sql变量用来存放删除员工的语句
$sql = "delete from pre_emp where emp_id = $emp_id ;";
//执行删除操作
$res =  mysqli_query($link,$sql);
//重置员工的id
$sql1 = "alter table pre_emp drop emp_id;";
$sql2 = "alter table pre_emp add emp_id int not null primary key auto_increment first;";
mysqli_query($link,$sql1);
mysqli_query($link,$sql2);

if ($res) {
    header('Location: ./show_emplist.php');
    exit;
} else {
    exit('删除员工失败');
}


