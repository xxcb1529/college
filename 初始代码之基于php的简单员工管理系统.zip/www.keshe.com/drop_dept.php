<?php
// 声明文件解析的编码格式

use PhpMyAdmin\Sql;

header('content-type:text/html;charset=utf-8');

//接入封装的各个函数
require './public_function.php';

//连接数据库
$link = dbInit();

// 获取要编辑的部门的id
$dept_id = isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0;

//定义一个sql语句用来查询部门是否还有人存在，存在返回删除失败信息
$sql3 = "select * from `pre_dept` join `pre_emp` on pre_dept.dept_id = pre_emp.emp_dept_id where `dept_id` = $dept_id; ";
if ($res = fetchAll_0($sql3)) {
    echo "<script> alert('部门删除失败！');history.back();</script>";
    exit;  
}

//定义一个sql变量用来存放删除部门的语句
$sql = "DELETE FROM `pre_dept` where `dept_id` = $dept_id;";

//执行删除操作
$res = mysqli_query($link,$sql);

//重置部门的id，先解除外键（因为部门表的主键为员工表的外键，必须先解除外键才可以重置id），最后在进行外键关联
$sql4 = "alter table `pre_emp` drop FOREIGN key FK_ID";
$sql1 = "alter table pre_dept drop dept_id;";
$sql2 = "alter table pre_dept add dept_id int not null primary key auto_increment first;";
$sql5 ="alter table pre_emp add foreign key FK_ID(emp_dept_id) references pre_dept(dept_id);";
mysqli_query($link,$sql4);
mysqli_query($link,$sql1);
mysqli_query($link,$sql2);
mysqli_query($link,$sql5);

if ($res) {
    header('Location: ./show_dept.php');
    exit;
} else {
    exit('删除部门信息失败');
}


