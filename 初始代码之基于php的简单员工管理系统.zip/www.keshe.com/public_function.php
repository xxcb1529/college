<?php

//封装连接函数
function dbInit() {
    static $link; // 利用静态变量保存数据库连接
    if (!$link) {
        $link = mysqli_connect('localhost','root','root');
        // 判断数据库连接是否成功，如果不成功则显示错误信息并终止脚本继续执行
        if (!$link) {
            exit('连接数据库失败！' . mysqli_connect_error());
        }
        // 设置字符集，选择数据库
        mysqli_set_charset($link, 'utf8');
        mysqli_select_db($link, 'keshe');
    } 
    return $link;
}

//封装sql执行语句函数
function query($sql) {
    $link = dbInit();
    if ($result = mysqli_query($link, $sql)) {
        // 执行成功
        return $result;
    } else {
        // 设定失败
        echo 'SQL执行失败:<br>';
        echo '错误的SQL为:', $sql, '<br>';
        echo '错误的代码为:', mysqli_errno($link), '<br>';
        echo '错误的信息为:', mysqli_error($link), '<br>';
        exit;
    }
}

//封装处理多条数据的函数 0
function fetchAll_0($sql) {

    // 执行query()函数
    if ($result = query($sql)) {
        // 执行成功
        // 遍历结果集
        $rows = array();
        while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $rows[] = $row;
        }
        // 释放结果集资源
        mysqli_free_result($result);
        return $rows;
    } else {
        // 执行失败
        return false;
    }
}

//封装处理多条数据的函数 1
function fetchAll_1($res) {
        // 遍历结果集，获取每位员工的详细数据
        $rows = array();
        while ($row = mysqli_fetch_assoc($res)) {
            $rows[] = $row; //把从结果集中取出的每一行数据赋值给$emp_info数组
        }
        // 返回数据集
        return $rows;
}

//封装处理单条数据的函数
function fetchRow($sql) {
    // 执行query()函数
    if ($result = query($sql)) {
        // 从结果集取得一次数据即可
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        return $row;
    } else {
        return false;
    }
}

//封装表单数据安全性过滤的函数
function safeHandle($data){
    //转义字符串中的HTML标签
    $data = htmlspecialchars($data);
    //转义字符串中的特殊字符
    $link = dbInit();
    $data = mysqli_real_escape_string($link, $data);
    return $data;
}

//封装已存在用户返回错误的函数用来判断用户是否存在
function already($username){
    if($_POST['username']==''){
        echo "<script> alert('请输入用户名！')</script>";
    }
    elseif($_POST['password']==''){
        echo "<script> alert('请输入密码！')</script>";
    }
    elseif($_POST['email'=='']){
        echo "<script> alert('请输入邮箱地址！')</script>";
    }
    //定义一个sql语句
    $sql = "select id from user where username = '$username'";
    //拼接sql语句进行查找
    $rst = query($sql);
    //进行用户名判断
    if (mysqli_fetch_row($rst)) {
        echo "<script> alert('用户名已注册！')</script>";
        exit('用户名已经存在，请换个用户名。');
        return false;
    }
    else{
        echo "注册成功";
        return true;
    }
}


//正则表达式的用法：验证各个变量
// 验证用户名（2~10位，只允许汉字，英文字母，数字，下划线）
// 注意：只支持验证UTF-8编码
function checkUsername($username) {
    if (!preg_match('/^[\w\x{4e00}-\x{9fa5}]{2,10}$/u', $username)) {
        return '用户名格式不符合要求';
    }
    return true;
}

// 验证密码（长度6~16位，首个必须以字母开头，只允许英文字母，数字，下划线）
function checkPassword($password) {
    if (!preg_match('/^[a-zA-Z]\w{6,16}$/',$password)) {
        return '密码格式不符合要求';
    }
    return true;
}

// 验证邮箱（不超过40位）
function checkEmail($email) {
    if (strlen($email) > 40) {
        return '邮箱长度不符合要求';
    } elseif (!preg_match('/^[a-z0-9]+@([a-z0-9]+\.)+[a-z]{2,4}$/i', $email)) {
        return '邮箱格式不符合要求';
    }
    return true;
}
// 验证QQ号（5~20位）
function checkQQ($qq) {
    if (!preg_match('/[1-9][0-9]{5,20}/',$qq)) {
        return 'QQ号码格式不符合要求';
    }
    return true;
}

// 验证手机号码（11位）
function checkPhone($num) {
    if (!preg_match('/^(13[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|18[0|1|2|3|5|6|7|8|9])\d{8}$/',$num)) {
        return '手机号码不符合要求';
    }
    return true;
}

// 验证URL地址（不超过200位）
function checkURL($url) {
    if (strlen($url) > 200) {
        return 'URL长度不符合要求';
    } elseif (!preg_match('/^http:\/\/[a-z\d-]+(\.[\w\/]+)+$/i',$url)) {
        return 'URL格式不符合要求';
    }
    return true;
}

//封装得到特定某用户的id
function getwho_id($who){
    $sql5 = "select emp_id from pre_emp where emp_name = '$who';";
    $whoid = query($sql5);
    return $whoid;
}

//封装经过部门名称得到部门id
function getdept_id($dept_name)
{
    //连接数据库
    $link = dbInit();
    //声明一个数组用来存放取得的数据
    $arr2=array();
    //定义一个sql变量来放语句
    $sql = "SELECT * FROM `pre_dept` WHERE dept_name = $dept_name;";
    //将取得的数据赋值给$cursor3
    $cursor3= mysqli_query($link,$sql);
    //循环将想要的数据赋值给$arr2数组
    while($row3=mysqli_fetch_array($cursor3)){
        $arr2[]=$row3['dept_id']; 
   }
    return $arr2[0];
}

//封装经过部门id得到部门名称
function getdept_name($dept_id)
{
    //连接数据库
    $link = dbInit();
    //声明一个数组用来存放取得的数据
    $arr2=array();
    //定义一个sql变量来放语句
    $sql = "SELECT * FROM `pre_dept` WHERE dept_id = $dept_id;";
    //将取得的数据赋值给$cursor3
    $cursor3= mysqli_query($link,$sql);
    //循环将想要的数据赋值给$arr2数组
    while($row3=mysqli_fetch_array($cursor3)){
        $arr2[]=$row3['dept_name'];
   }
    return $arr2[0];
}

//封装经过员工id查询得到该员工所在的部门
function getdept($emp_id)
{
    //连接数据库
    $link = dbInit();
    //声明一个数组用来存放取得的数据
    $arr2=array();
    //定义一个sql变量来放语句
    $sql = "SELECT * FROM `pre_dept` join `pre_emp` on pre_dept.dept_id = pre_emp.emp_dept_id WHERE emp_id = $emp_id;";
    //将取得的数据赋值给$cursor3
    $cursor3= mysqli_query($link,$sql);
    //循环将想要的数据赋值给$arr2数组
    while($row3=mysqli_fetch_array($cursor3)){
        $arr2[]=$row3['dept_name']; 
   }
    return $arr2[0];
}


//封装从数据库查询到pre_dept的dept_name数据赋值给一个数组并返回该数组
function getName(){
    //连接数据库
    $link = dbInit();
    //声明一个数组用来存放取得的数据
    $arr2=array();
    //定义一个sql变量来放语句
    $sql = "SELECT * from pre_dept";
    //将取得的数据赋值给$cursor3
    $cursor3= mysqli_query($link,$sql);
    //循环将想要的数据赋值给$arr2数组
    while($row3=mysqli_fetch_array($cursor3)){
        $arr2[]=$row3['dept_name']; 
    }
   return $arr2;
}

//定义一个返回界面的工具类和方法
class tool {
    //该方法在某个操作执行成功并需要跳转到指定页面时使用
    public static function alertGo($info, $url) {
        //弹出一个对话框，提示$info中的信息，然后location跳转到$_url指定的页面
        echo "<script>alert('$info');location.href='$url';</script>";
        exit();
    }
    /**
     * JavaScript 弹窗返回
     * @param string $info 跳转信息 
     * @return string 返回能够执行跳转的JavaScript代码
     */
    //该方法在某个操作执行失败时使用
    public static function alertBack($info) {
        //弹出对话框，提示$info变量中的信息，然后返回上一个访问的页面
        echo "<script>alert('$info');history.back();</script>";
        exit();
    }
}
function back(){
    echo "<script>history.back();</script>";
    exit();
}
