<?php
// 声明文件解析的编码格式
header('content-type:text/html;charset=utf-8');

//接入封装的各个函数
require './public_function.php';

// 接入连接封装的函数，连接数据库
$link = dbInit();

// 定义变量，用来保存查询条件，初始化赋值空字符串
$where = '';

// 判断是否有搜索关键字传入
if (isset($_GET['keyword'])) {

    // 将$_GET['keyword']赋值给变量$keyword
    $keyword = $_GET['keyword'];

    // 用户输入的搜索信息不能直接使用，其中可能存在导致SQL语句执行失败的关键字或特殊字符，需要使用mysqli_real_escape_string()函数进行转义
    $keyword = mysqli_real_escape_string($link, $keyword);

    // 将转义后的关键字拼接到where条件查询中，并且使用like进行模糊查询
    $where = "where emp_name like '%$keyword%'";
}

// 把查询条件$where拼接到SQL语句中
$sql1 = "select * from `pre_dept` join pre_emp on pre_dept.dept_id = pre_emp.emp_dept_id $where order by pre_emp.emp_id asc";


//分页开始
// 获取数据总数
$page_size = 6;

//接入封装sql执行语句
$sql_count = "select count(*) from `pre_emp`";
$res = query($sql_count);
if (!$res) {
    exit(mysqli_error($link));
}

$count = mysqli_fetch_row($res);
//取出查询结果中的第一列的值
$count = $count[0];
//计算最大页码值
$max_page = ceil($count / $page_size);
// 获取当前选择的页码，并作容错处理
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
if(isset($_GET['selsub'])){
	$page = isset($_GET['getpage']) ? intval($_GET['getpage']) :1;
}
$page = $page > $max_page ? $max_page : $page;
$page = $page < 1 ? 1 : $page;

// 组合分页链接
$page_html = "<a href='./show_emplist.php?page=1'>首页</a>&nbsp;";
$page_html .= "<a href='./show_emplist.php?page=" . (($page - 1) > 0 ? ($page - 1) : 1)."'>上一页</a>&nbsp;";
$page_html .= "<a href='./show_emplist.php?page=" . (($page + 1) < $max_page ? ($page + 1) : $max_page)."'>下一页</a>&nbsp;";
$page_html .= "<a href='./show_emplist.php?page={$max_page}'>尾页</a>";

// 准备SQL语句
$lim = ($page -1) * $page_size;
$sql3 = "select * from `pre_dept` join `pre_emp` on pre_dept.dept_id = pre_emp.emp_dept_id order by pre_emp.emp_id asc limit {$lim}, {$page_size}";
//分页结束


//允许排序的字段
$fields = array('emp_id','emp_name','emp_dept_id','emp_birth', 'emp_entry');
// 初始化排序语句，用来组合排序的order子句
$sql_order = '';

//判断$_GET['order']是否存在，如果存在则将其赋值给$order，如果不存在则把空字符串赋值给$order
$order = isset($_GET['order']) ? $_GET['order'] : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : '';
//判断$order是否存在于合法字段列表$fields中
if (in_array($order, $fields)) {
    //判断$_GET['sort']是否存在并且值是否为'desc'
    if ($sort == 'desc') {
        //条件成立，组合order子句   order by 字段 desc
        $sql_order = "order by $order desc";
        //更新$sort为'asc'
        $sort = 'asc';
    } else {
        //条件不成立，组合order子句   order by 字段 asc
        $sql_order = "order by $order asc";
        //更新$sort为'desc'
        $sort = 'desc';
    }
}


$clkBool = "<script> document.writeln(clkBool);</script>" ;

// 准备SQL语句
$sql = 'select * from `pre_dept` join `pre_emp` on pre_dept.dept_id = pre_emp.emp_dept_id order by pre_emp.emp_id asc';
$sql2 = "select * from `pre_dept` join `pre_emp` on pre_dept.dept_id = pre_emp.emp_dept_id $sql_order limit {$lim}, {$page_size}";
$sql4 = "select * from `pre_dept` join `pre_emp` on pre_dept.dept_id = pre_emp.emp_dept_id $sql_order";
// 执行SQL语句，获取结果集
if (isset($_GET['sub'])) {
	//如果输入的为空值则不进行查询操作
	if($keyword=='') 
		$res = query($sql3);
	else
    	$res = query($sql1);
}elseif($order!=''&&$sort!='') {
	if($clkBool == 'true')
		$res = query($sql4);
	else
    	$res = query($sql2);
}else{
    $res = query($sql3);
}
if(isset($_GET['all'])) {
	//如果点击显示全部按钮则进行查询全部信息
    $res = query($sql);
}elseif(isset($_GET['return'])){
	//如果点击返回分页按钮则返回分页页面
	$res = query($sql2);
}
if(!$res) {
    exit(mysqli_error($link));
}
// //定义员工数组，用以保存员工信息
// $emp_info = array();

// 定义员工数组，用以保存员工信息
$pre_emp = fetchAll_1($res);

// 设置常量，用以判断视图页面是否由此页面加载
define('APP', 'itcast');
?>

<!-- // 加载视图页面，显示数据 -->
<?php if (!defined('APP')) {
    die('error!');
}?>
<!doctype html>
<html>
 <head>
  <meta charset="utf-8">
  <title>员工信息列表</title>
  <style>
    a{text-decoration: none; color: black;}
	a:hover{text-decoration: underline; color: #B5D6E6;}
	.box{margin:50px; background-color: white; padding: 20px; height: 320px;}
	.box .title{font-size:25px;font-weight:bold;text-align:center;}
	.search{float: right; margin-bottom: 10px;}
	.box table{width:100%;margin-top:15px;border-collapse:collapse;font-size:15px;border:1px solid #B5D6E6;min-width:460px;}
	.box table th,.box table td{height:20px;border:1px solid #B5D6E6;}
	.box table th{background-color:#E8F6FC;font-weight:bold;}
	.box table td{text-align:center;height: 25px;}
	.page{margin-top: 20px; float: right; word-spacing: 15px;}
	.addemp{float: right;margin-right: 43px; clear: both; margin-top: 5px;}
  </style>
</head>
<body>
  <form action="show_emplist.php" method="GET" style="position: relative;">
	<div class="box">
		<div class="title">员工信息列表</div>
        <div class="search">
			快速查询：<input type="text" name="keyword"/> 
			<input type="submit" name="sub" value="提交"/>
        	<input type="submit" name="all" value="显示全部" onclick="Clicked1()"/>
			<input type="submit" name="return" value="返回分页" onclick="Clicked2()"/>
    	</div>
		<table border="1">
			<tr>
				<th width="5%"><a href="./show_emplist.php?order=emp_id&sort=<?php echo ($order=='emp_id') ? $sort : 'desc';?>">ID</a></th>
                <th><a href="./show_emplist.php?order=emp_name&sort=<?php echo ($order=='emp_name') ? $sort : 'desc';?>">姓名</a></th>
                <th><a href="./show_emplist.php?order=emp_dept_id&sort=<?php echo ($order=='emp_dept_id') ? $sort : 'desc';?>">所属部门</a></th>
                <th><a href="./show_emplist.php?order=emp_birth&sort=<?php echo ($order=='emp_birth') ? $sort : 'desc';?>">出生日期</a></th>
                <th><a href="./show_emplist.php?order=emp_entry&sort=<?php echo ($order=='emp_entry') ? $sort : 'desc';?>">入职时间</a></th>
                <th width="25%">相关操作</th>
			</tr>
			<?php  if (!empty($pre_emp)) { ?>
			<?php foreach ($pre_emp as $row) { ?>
			<tr>
				 <td style="width: 1%;"><?php echo $row['emp_id']; ?></td>
				 <td style="width: 10%;"><?php echo $row['emp_name']; ?></td>
				 <td style="width: 10%;"><?php echo $row['dept_name']; ?></td>
				 <td style="width: 20%;"><?php echo $row['emp_birth']; ?></td>
				 <td style="width: 20%;"><?php echo $row['emp_entry']; ?></td>
				 <td style="width: 12%;"><div align="center">
					<span>
						<a href="<?php echo './empUpdate.php?emp_id='.$row['emp_id'] ?>"><img src="images/edt.gif" width="16" height="16" />编辑</a>&nbsp; &nbsp;
						<a href="<?php echo './drop_emp.php?emp_id='.$row['emp_id'] ?>" name="drop"><img src="images/del.gif" width="16" height="16" />删除</a>
					</span>
				</div></td>
			</tr>
			<?php } ?>
			<?php  } else {   ?>
					<tr><td colspan="6">查询的结果不存在！</td></tr>
			<?php } ?>
		</table>
		<div class="page">
			<?php echo $page_html; ?>
			<div>
				<span>共 <?php echo $max_page?> 页</span>
				<span>当前第<input type="text" value="<?php echo $page?>" size="1" name="getpage">页</span>
				<input type="submit" name="selsub" id="" value="前往">
			</div>
		</div>
		<div class="addemp">
	  		<a href="./addEmp.php">添加员工</a>
	  		<a href="./show_dept.php">部门管理</a>
		</div>
	</div>
  </form>
</body>
<script>
	var clkBool=false;
	function Clicked1(){clkBool=true; } 
	function Clicked2(){clkBool=false; } 
</script>
</html>


