<?php
// 声明文件解析的编码格式
header('content-type:text/html;charset=utf-8');

//接入封装的各个函数
require './public_function.php';

// 接入连接封装的函数，连接数据库
$link = dbInit();

// 声明变量$field，用来保存字段信息
$field = '`dept_name`';

//获取想要修改的部门的id
$dept_id = $_COOKIE['dept_id'];
// 将得到的id进行语句查询得到部门名称赋值给输入框,并保存修改历史
$oldName = $_COOKIE['oldName'];

//添加新部门
if(isset($_GET['sub_add'])){
    //获取想要添加的部门名称
    $dept_name = isset($_GET['keyword1']) ? $_GET['keyword1'] : '';
    
    if($dept_name == '')
    {
        echo "<script> alert('部门添加失败！');history.back();</script>";
        exit;
    }

    //定义一个sql变量用来添加新数据
    $sql1 = "insert into `pre_dept`($field) values ('$dept_name') ";

    // 执行SQL
    if ($res = query($sql1)) {
        // 成功时返回到 show_dept.php
        header('Location: ./show_dept.php');
        // 停止脚本
        exit;
    } else {
        // 执行失败
        exit('部门添加失败！');
    }
}

//修改部门名称
if(isset($_GET['sub_upd'])){
    //获取想要修改的新部门名称,并进行转义
    $newName = isset($_GET['keyword2'])? $_GET['keyword2'] :'';
    if($newName !=''){
        $newName = "'$newName'";
        //定义一个sql变量用来修改数据
        $sql4 = "UPDATE `pre_dept` SET $field = $newName where dept_id = $dept_id; ";
        // 执行SQL
        if ($res = query($sql4)) {
            // 成功时返回到 show_dept.php
            header('Location: ./show_dept.php');
            // 停止脚本
            exit;
        } else {
            // 执行失败
            exit('部门信息修改失败！');
        }
    }else {
        // 执行失败
        exit('部门信息修改失败！');
    }
    
}

//允许排序的字段
$fields = array('dept_id','dept_name');
// 初始化排序语句，用来组合排序的order子句
$sql_order = '';

//判断$_GET['order']是否存在，如果存在则将其赋值给$order，如果不存在则把空字符串赋值给$order
$order = isset($_GET['order']) ? $_GET['order'] : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : '';
//判断$order是否存在于合法字段列表$fields中
if (in_array($order, $fields)) {
    //判断$_GET['sort']是否存在并且值是否为'desc'
    if ($sort == 'desc') {
        //条件成立，组合order子句   order by 字段 desc
        $sql_order = "order by $order desc";
        //更新$sort为'asc'
        $sort = 'asc';
    } else {
        //条件不成立，组合order子句   order by 字段 asc
        $sql_order = "order by $order asc";
        //更新$sort为'desc'
        $sort = 'desc';
    }
}

// 准备SQL语句
$sql = 'select * from `pre_dept`';
$sql2 = "select * from `pre_dept` $sql_order";

// 执行SQL语句，获取结果集
if($order!=''&&$sort!='') {
    $res = query($sql2);
}else{
    $res = query($sql);
}
if(!$res) {
    exit(mysqli_error($link));
}

// 定义部门数组，用以保存部门信息
$pre_dept = fetchAll_1($res);

// 设置常量，用以判断视图页面是否由此页面加载
define('APP', 'itcast');
?>

<!-- // 加载视图页面，显示数据 -->
<?php if (!defined('APP')) {
    die('error!');
}?>
<!doctype html>
<html>
 <head>
  <meta charset="utf-8">
  <title>部门管理表</title>
  <style>
    a{text-decoration: none; color: black;}
	a:hover{text-decoration: underline; color: #B5D6E6;}
	.box{margin:50px; background-color: white; padding: 20px; height: 320px;}
	.box .title{font-size:25px;font-weight:bold;text-align:center;}
	.search{float: right; margin-bottom: 10px;}
	.box table{width:60%;margin: 0 auto; margin-top:15px;border-collapse:collapse;font-size:15px;border:1px solid #B5D6E6;min-width:460px;}
	.box table th,.box table td{height:20px;border:1px solid #B5D6E6;}
	.box table th{background-color:#E8F6FC;font-weight:bold;}
	.box table td{text-align:center;height: 25px;}
    .search{float: right; margin-right: 250px; margin-top: 20px;}
    .return{margin-left: 220px; margin-top: 10px;}
  </style>
</head>
<body>
  <form action="show_dept.php" method="GET" style="position: relative;">
	<div class="box">
		<div class="title">部门管理</div>
		<table border="1">
			<tr>
				<th width="5%"><a href="./show_dept.php?order=dept_id&sort=<?php echo ($order=='dept_id') ? $sort : 'desc';?>">ID</a></th>
                <th ><a href="./show_dept.php?order=dept_name&sort=<?php echo ($order=='dept_name') ? $sort : 'desc';?>">部门名称</a></th>
                <th width="25%">相关操作</th>
			</tr>
			<?php  if (!empty($pre_dept)) { ?>
			<?php foreach ($pre_dept as $row) { ?>
			<tr>
				 <td style="width: 1%;"><?php echo $row['dept_id']; ?></td>
				 <td style="width: 25%;"><?php echo $row['dept_name']; ?></td>
				 <td style="width: 12%;"><div align="center">
					<span>
						<a href="<?php echo './update_dept.php?dept_id='.$row['dept_id'] ?>" name="update"><img src="images/edt.gif" width="16" height="16" />修改</a>&nbsp; &nbsp;
						<a href="<?php echo './drop_dept.php?dept_id='.$row['dept_id'] ?>" name="drop"><img src="images/del.gif" width="16" height="16" />删除</a>
					</span>
				</div></td>
			</tr>
			<?php } ?>
			<?php  } else {   ?>
					<tr><td colspan="6">查询的结果不存在！</td></tr>
			<?php } ?>
		</table>
        <div class="search">
			添加部门：<input type="text" name="keyword1"/> <input type="submit" name="sub_add" value="提交"/><br>
			修改部门名称：<input type="text" name="keyword2" value="<?php echo $oldName ?>"/> <input type="submit" name="sub_upd" value="提交"/>
            <div class="return"><a href="<?php echo './show_emplist.php' ?>">返回员工列表</a></div>
    	</div>
	</div>
  </form>
  
</body>
</html>

