<?php
// 声明文件解析的编码格式
header('content-type:text/html;charset=utf-8');

// 引入功能函数文件
require './public_function.php';


//声明一个变量用来存放sql语句
$department = array();
$department = getName();

//从部门表中经过语句查询到的部门名字赋值给$department数组


// 判断是否有表单提交
if (!empty($_POST)) {

    // 声明变量$fields，用来保存字段信息
    $fields = array( 'emp_name', 'dept_name', 'emp_birth', 'emp_entry');

    // 声明变量$values，用来保存值信息
    $values = array(); 
    
    // 遍历$fields，获取输入员工数据的键和值
    foreach ($fields as $k => $v) {

        $data = isset($_POST[$v]) ? $_POST[$v] : '';

        if ($data == '') {
            exit($v.'字段不能为空');
        }

        $data = safeHandle($data);

        // 把字段使用反引号包裹，赋值给$fields数组
        $fields[$k] = "`$v`";

        //先判断字段是否为数字，是的话直接赋值给$values数组；不是则用单引号包裹再赋值
        if( is_numeric ($data))
            $values[] = "$data";
        else
            $values[] = "'$data'";
    }
    
    //从$values数组中取出dept_name
    $value = $values[1];
    //将dept_name更改为`emp_dept_id`
    $fields[1] = '`emp_dept_id`';
    //得到特定部门的id
    $emp_dept_id = getdept_id($value);
    //将得到的id赋值给$values数组中的第二项
    $values[1] = $emp_dept_id;

    // 将$fields数组以逗号连接，赋值给$fields，组成insert语句中的字段部分
    $fields = implode(',', $fields);

    // 将$values数组以逗号连接，赋值给$values，组成insert语句中的值部分
    $values = implode(',', $values);

    // 最后把$fields和$values拼接到insert语句中，注意要指定表名
    $sql = "insert into `pre_emp` ($fields) values ($values)";

    // 执行SQL
    if ($res = query($sql)) {
        // 成功时返回到 showList.php
        header('Location: ./show_emplist.php');
        // 停止脚本
        exit;
    } else {
        // 执行失败
        exit('员工添加失败！');
    }
}

// 没有表单提交时，显示员工添加页面
define('APP', 'itcast');
?>

<?php if(!defined('APP')) die('error!');?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>添加员工</title>
<link rel="stylesheet" href="./jquery.datetimepicker.css"/>
<script src="./jquery.js"></script>
<script src="./jquery.datetimepicker.js"></script>
<script>
	$(function(){
		$('#date_of_birth').datetimepicker({lang:'ch'});
		$('#date_of_entry').datetimepicker({lang:'ch'});
	});
</script>
<style>
body{background-color:#eee;margin:0;padding:0;}
.box{width:400px;margin:15px auto;padding:20px;border:1px solid #ccc;background-color:#fff;}
.box h1{font-size:20px;text-align:center;}
.profile-table{margin:0 auto;}
.profile-table th{font-weight:normal;text-align:right;}
.profile-table input[type="text"]{width:180px;border:1px solid #ccc;height:22px;padding-left:4px;}
.profile-table .button{background-color:#0099ff;border:1px solid #0099ff;color:#fff;width:80px;height:25px;margin:0 5px;cursor:pointer;}
.profile-table .td-btn{text-align:center;padding-top:10px;}
.profile-table th,.profile-table td{padding-bottom:10px;}
.profile-table td{font-size:14px;}
.profile-table .txttop{vertical-align:top;}
.profile-table select{border:1px solid #ccc;min-width:80px;height:25px;}
.profile-table .description{font-size:13px;width:250px;height:60px;border:1px solid #ccc;}
</style>
</head>
<body>
<div class="box">
	<h1>添加员工</h1>
	<form method="post" action="./addEmp.php">
	<table class="profile-table">
		<tr><th>姓名：</th><td><input type="text" name="emp_name" /></td></tr>
        <tr><th>所属部门：</th><td>
        <select style="width: 185px;" name="dept_name">
				<option value="未选择">未选择</option>
				<?php foreach($department as $v): ?>
					<option> <?php echo $v ?> </option>
				<?php endForeach; ?>
		</select>
        <!-- <input type="text" name="emp_dept_id" /></td></tr> -->
		<tr><th>出生年月：</th><td><input id="emp_birth" name="emp_birth" type="text" ></td></tr>
		<tr><th>入职日期：</th><td><input id="emp_entry" name="emp_entry" type="text" ></td></tr>
		<tr><td colspan="2" class="td-btn">
		<input type="submit" value="保存资料" class="button" />
		<input type="button" value="返回列表" class="button" onclick="window.open('show_emplist.php')" />
		</td></tr>
	</table>
	</form>
</div>
</body>
</html>

